﻿namespace SayangDiniUas
{
    partial class dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel13 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.bukulbl = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.guna2GradientTileButton1 = new Guna.UI2.WinForms.Guna2GradientTileButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.anggota = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.petugas = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.pinjam = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.kembali = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.guna2GradientTileButton8 = new Guna.UI2.WinForms.Guna2GradientTileButton();
            this.guna2GradientTileButton9 = new Guna.UI2.WinForms.Guna2GradientTileButton();
            this.guna2GradientTileButton10 = new Guna.UI2.WinForms.Guna2GradientTileButton();
            this.guna2GradientTileButton11 = new Guna.UI2.WinForms.Guna2GradientTileButton();
            this.guna2GradientTileButton12 = new Guna.UI2.WinForms.Guna2GradientTileButton();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2GradientTileButton13 = new Guna.UI2.WinForms.Guna2GradientTileButton();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel6.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.Red;
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel13.Controls.Add(this.label11);
            this.panel13.Controls.Add(this.bukulbl);
            this.panel13.Controls.Add(this.pictureBox6);
            this.panel13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel13.Location = new System.Drawing.Point(619, 146);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(196, 77);
            this.panel13.TabIndex = 77;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(79, 5);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 20);
            this.label11.TabIndex = 73;
            this.label11.Text = "Buku";
            // 
            // bukulbl
            // 
            this.bukulbl.AutoSize = true;
            this.bukulbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bukulbl.ForeColor = System.Drawing.Color.White;
            this.bukulbl.Location = new System.Drawing.Point(90, 28);
            this.bukulbl.Name = "bukulbl";
            this.bukulbl.Size = new System.Drawing.Size(26, 29);
            this.bukulbl.TabIndex = 73;
            this.bukulbl.Text = "0";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::SayangDiniUas.Properties.Resources.buku1;
            this.pictureBox6.Location = new System.Drawing.Point(1, 1);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(72, 70);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 1;
            this.pictureBox6.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Lucida Handwriting", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(91, 79);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(93, 42);
            this.label12.TabIndex = 96;
            this.label12.Text = "Ayo baca\r\nBukumu";
            // 
            // guna2GradientTileButton1
            // 
            this.guna2GradientTileButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton1.BorderRadius = 7;
            this.guna2GradientTileButton1.BorderThickness = 2;
            this.guna2GradientTileButton1.CheckedState.Parent = this.guna2GradientTileButton1;
            this.guna2GradientTileButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientTileButton1.CustomImages.Parent = this.guna2GradientTileButton1;
            this.guna2GradientTileButton1.FillColor = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton1.FillColor2 = System.Drawing.Color.DarkSlateBlue;
            this.guna2GradientTileButton1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GradientTileButton1.ForeColor = System.Drawing.Color.White;
            this.guna2GradientTileButton1.HoverState.BorderColor = System.Drawing.Color.GhostWhite;
            this.guna2GradientTileButton1.HoverState.FillColor = System.Drawing.Color.Green;
            this.guna2GradientTileButton1.HoverState.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton1.HoverState.ForeColor = System.Drawing.Color.White;
            this.guna2GradientTileButton1.HoverState.Parent = this.guna2GradientTileButton1;
            this.guna2GradientTileButton1.Image = global::SayangDiniUas.Properties.Resources.user2;
            this.guna2GradientTileButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientTileButton1.ImageOffset = new System.Drawing.Point(0, 23);
            this.guna2GradientTileButton1.ImageSize = new System.Drawing.Size(43, 43);
            this.guna2GradientTileButton1.Location = new System.Drawing.Point(9, 145);
            this.guna2GradientTileButton1.Name = "guna2GradientTileButton1";
            this.guna2GradientTileButton1.ShadowDecoration.Parent = this.guna2GradientTileButton1;
            this.guna2GradientTileButton1.Size = new System.Drawing.Size(191, 48);
            this.guna2GradientTileButton1.TabIndex = 89;
            this.guna2GradientTileButton1.Text = "Petugas";
            this.guna2GradientTileButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientTileButton1.TextOffset = new System.Drawing.Point(-33, -25);
            this.guna2GradientTileButton1.Click += new System.EventHandler(this.guna2GradientTileButton1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.anggota);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel2.Location = new System.Drawing.Point(418, 146);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(196, 77);
            this.panel2.TabIndex = 80;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(78, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 20);
            this.label1.TabIndex = 73;
            this.label1.Text = "Anggota";
            // 
            // anggota
            // 
            this.anggota.AutoSize = true;
            this.anggota.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.anggota.ForeColor = System.Drawing.Color.White;
            this.anggota.Location = new System.Drawing.Point(87, 29);
            this.anggota.Name = "anggota";
            this.anggota.Size = new System.Drawing.Size(26, 29);
            this.anggota.TabIndex = 73;
            this.anggota.Text = "0";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::SayangDiniUas.Properties.Resources.zyro_image__3_;
            this.pictureBox2.Location = new System.Drawing.Point(1, 1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(72, 70);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 79;
            this.pictureBox2.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.ForestGreen;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.petugas);
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel3.Location = new System.Drawing.Point(217, 146);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(196, 77);
            this.panel3.TabIndex = 82;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(78, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 20);
            this.label3.TabIndex = 73;
            this.label3.Text = "Petugas";
            // 
            // petugas
            // 
            this.petugas.AutoSize = true;
            this.petugas.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.petugas.ForeColor = System.Drawing.Color.White;
            this.petugas.Location = new System.Drawing.Point(92, 28);
            this.petugas.Name = "petugas";
            this.petugas.Size = new System.Drawing.Size(26, 29);
            this.petugas.TabIndex = 73;
            this.petugas.Text = "0";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::SayangDiniUas.Properties.Resources.user1;
            this.pictureBox3.Location = new System.Drawing.Point(1, 1);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(72, 70);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 81;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.pinjam);
            this.panel4.Controls.Add(this.pictureBox4);
            this.panel4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel4.Location = new System.Drawing.Point(820, 146);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(196, 77);
            this.panel4.TabIndex = 84;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(78, 4);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 20);
            this.label5.TabIndex = 73;
            this.label5.Text = "Pinjam";
            // 
            // pinjam
            // 
            this.pinjam.AutoSize = true;
            this.pinjam.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pinjam.ForeColor = System.Drawing.Color.White;
            this.pinjam.Location = new System.Drawing.Point(86, 27);
            this.pinjam.Name = "pinjam";
            this.pinjam.Size = new System.Drawing.Size(26, 29);
            this.pinjam.TabIndex = 73;
            this.pinjam.Text = "0";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::SayangDiniUas.Properties.Resources.zyro_image__6_;
            this.pictureBox4.Location = new System.Drawing.Point(1, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(72, 70);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 83;
            this.pictureBox4.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.label7);
            this.panel5.Controls.Add(this.kembali);
            this.panel5.Controls.Add(this.pictureBox5);
            this.panel5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel5.Location = new System.Drawing.Point(216, 260);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(196, 77);
            this.panel5.TabIndex = 86;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(77, 5);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 20);
            this.label7.TabIndex = 73;
            this.label7.Text = "Pengembalian";
            // 
            // kembali
            // 
            this.kembali.AutoSize = true;
            this.kembali.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kembali.ForeColor = System.Drawing.Color.White;
            this.kembali.Location = new System.Drawing.Point(92, 24);
            this.kembali.Name = "kembali";
            this.kembali.Size = new System.Drawing.Size(26, 29);
            this.kembali.TabIndex = 73;
            this.kembali.Text = "0";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::SayangDiniUas.Properties.Resources.Homepage_pinjam_unduh1;
            this.pictureBox5.Location = new System.Drawing.Point(1, 1);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(72, 70);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 85;
            this.pictureBox5.TabStop = false;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Font = new System.Drawing.Font("Kristen ITC", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel6.Location = new System.Drawing.Point(1, 598);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1028, 10);
            this.panel6.TabIndex = 88;
            // 
            // panel7
            // 
            this.panel7.Location = new System.Drawing.Point(0, 54);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(10, 440);
            this.panel7.TabIndex = 22;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel11.Location = new System.Drawing.Point(1025, 39);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(3, 560);
            this.panel11.TabIndex = 24;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel8.Controls.Add(this.label2);
            this.panel8.Controls.Add(this.pictureBox1);
            this.panel8.Controls.Add(this.label13);
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1028, 64);
            this.panel8.TabIndex = 95;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Gloucester MT Extra Condensed", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(6, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 32);
            this.label2.TabIndex = 96;
            this.label2.Text = "?";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = global::SayangDiniUas.Properties.Resources.cancel;
            this.pictureBox1.Location = new System.Drawing.Point(995, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(34, 33);
            this.pictureBox1.TabIndex = 97;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Lucida Calligraphy", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(245, 19);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(539, 27);
            this.label13.TabIndex = 96;
            this.label13.Text = "Selamat Datang Di Perpustakaan Informatika";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Gloucester MT Extra Condensed", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(233, 89);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 32);
            this.label10.TabIndex = 95;
            this.label10.Text = "Home";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel1.Location = new System.Drawing.Point(0, 37);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(3, 560);
            this.panel1.TabIndex = 97;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel9.Location = new System.Drawing.Point(208, 37);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(3, 560);
            this.panel9.TabIndex = 98;
            // 
            // guna2GradientTileButton8
            // 
            this.guna2GradientTileButton8.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton8.BorderRadius = 7;
            this.guna2GradientTileButton8.BorderThickness = 2;
            this.guna2GradientTileButton8.CheckedState.Parent = this.guna2GradientTileButton8;
            this.guna2GradientTileButton8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientTileButton8.CustomImages.Parent = this.guna2GradientTileButton8;
            this.guna2GradientTileButton8.FillColor = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton8.FillColor2 = System.Drawing.Color.DarkSlateBlue;
            this.guna2GradientTileButton8.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GradientTileButton8.ForeColor = System.Drawing.Color.White;
            this.guna2GradientTileButton8.HoverState.BorderColor = System.Drawing.Color.GhostWhite;
            this.guna2GradientTileButton8.HoverState.FillColor = System.Drawing.Color.Red;
            this.guna2GradientTileButton8.HoverState.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton8.HoverState.ForeColor = System.Drawing.Color.White;
            this.guna2GradientTileButton8.HoverState.Parent = this.guna2GradientTileButton8;
            this.guna2GradientTileButton8.Image = global::SayangDiniUas.Properties.Resources.buku1;
            this.guna2GradientTileButton8.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientTileButton8.ImageOffset = new System.Drawing.Point(0, 24);
            this.guna2GradientTileButton8.ImageSize = new System.Drawing.Size(50, 45);
            this.guna2GradientTileButton8.Location = new System.Drawing.Point(9, 202);
            this.guna2GradientTileButton8.Name = "guna2GradientTileButton8";
            this.guna2GradientTileButton8.ShadowDecoration.Parent = this.guna2GradientTileButton8;
            this.guna2GradientTileButton8.Size = new System.Drawing.Size(191, 48);
            this.guna2GradientTileButton8.TabIndex = 99;
            this.guna2GradientTileButton8.Text = "Buku";
            this.guna2GradientTileButton8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientTileButton8.TextOffset = new System.Drawing.Point(-53, -25);
            this.guna2GradientTileButton8.Click += new System.EventHandler(this.guna2GradientTileButton8_Click);
            // 
            // guna2GradientTileButton9
            // 
            this.guna2GradientTileButton9.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton9.BorderRadius = 7;
            this.guna2GradientTileButton9.BorderThickness = 2;
            this.guna2GradientTileButton9.CheckedState.Parent = this.guna2GradientTileButton9;
            this.guna2GradientTileButton9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientTileButton9.CustomImages.Parent = this.guna2GradientTileButton9;
            this.guna2GradientTileButton9.FillColor = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton9.FillColor2 = System.Drawing.Color.DarkSlateBlue;
            this.guna2GradientTileButton9.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GradientTileButton9.ForeColor = System.Drawing.Color.White;
            this.guna2GradientTileButton9.HoverState.BorderColor = System.Drawing.Color.GhostWhite;
            this.guna2GradientTileButton9.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.guna2GradientTileButton9.HoverState.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton9.HoverState.ForeColor = System.Drawing.Color.White;
            this.guna2GradientTileButton9.HoverState.Parent = this.guna2GradientTileButton9;
            this.guna2GradientTileButton9.Image = global::SayangDiniUas.Properties.Resources.zyro_image__3_;
            this.guna2GradientTileButton9.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientTileButton9.ImageOffset = new System.Drawing.Point(0, 27);
            this.guna2GradientTileButton9.ImageSize = new System.Drawing.Size(47, 48);
            this.guna2GradientTileButton9.Location = new System.Drawing.Point(10, 259);
            this.guna2GradientTileButton9.Name = "guna2GradientTileButton9";
            this.guna2GradientTileButton9.ShadowDecoration.Parent = this.guna2GradientTileButton9;
            this.guna2GradientTileButton9.Size = new System.Drawing.Size(191, 48);
            this.guna2GradientTileButton9.TabIndex = 100;
            this.guna2GradientTileButton9.Text = "Anggota";
            this.guna2GradientTileButton9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientTileButton9.TextOffset = new System.Drawing.Point(-30, -26);
            this.guna2GradientTileButton9.Click += new System.EventHandler(this.guna2GradientTileButton9_Click);
            // 
            // guna2GradientTileButton10
            // 
            this.guna2GradientTileButton10.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton10.BorderRadius = 7;
            this.guna2GradientTileButton10.BorderThickness = 2;
            this.guna2GradientTileButton10.CheckedState.Parent = this.guna2GradientTileButton10;
            this.guna2GradientTileButton10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientTileButton10.CustomImages.Parent = this.guna2GradientTileButton10;
            this.guna2GradientTileButton10.FillColor = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton10.FillColor2 = System.Drawing.Color.DarkSlateBlue;
            this.guna2GradientTileButton10.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GradientTileButton10.ForeColor = System.Drawing.Color.White;
            this.guna2GradientTileButton10.HoverState.BorderColor = System.Drawing.Color.GhostWhite;
            this.guna2GradientTileButton10.HoverState.FillColor = System.Drawing.Color.DarkSlateBlue;
            this.guna2GradientTileButton10.HoverState.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton10.HoverState.ForeColor = System.Drawing.Color.White;
            this.guna2GradientTileButton10.HoverState.Parent = this.guna2GradientTileButton10;
            this.guna2GradientTileButton10.Image = global::SayangDiniUas.Properties.Resources.zyro_image__6_;
            this.guna2GradientTileButton10.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientTileButton10.ImageOffset = new System.Drawing.Point(0, 23);
            this.guna2GradientTileButton10.ImageSize = new System.Drawing.Size(43, 42);
            this.guna2GradientTileButton10.Location = new System.Drawing.Point(10, 316);
            this.guna2GradientTileButton10.Name = "guna2GradientTileButton10";
            this.guna2GradientTileButton10.ShadowDecoration.Parent = this.guna2GradientTileButton10;
            this.guna2GradientTileButton10.Size = new System.Drawing.Size(191, 48);
            this.guna2GradientTileButton10.TabIndex = 101;
            this.guna2GradientTileButton10.Text = "Peminjaman";
            this.guna2GradientTileButton10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientTileButton10.TextOffset = new System.Drawing.Point(-1, -25);
            this.guna2GradientTileButton10.Click += new System.EventHandler(this.guna2GradientTileButton10_Click);
            // 
            // guna2GradientTileButton11
            // 
            this.guna2GradientTileButton11.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton11.BorderRadius = 7;
            this.guna2GradientTileButton11.BorderThickness = 2;
            this.guna2GradientTileButton11.CheckedState.Parent = this.guna2GradientTileButton11;
            this.guna2GradientTileButton11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientTileButton11.CustomImages.Parent = this.guna2GradientTileButton11;
            this.guna2GradientTileButton11.FillColor = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton11.FillColor2 = System.Drawing.Color.DarkSlateBlue;
            this.guna2GradientTileButton11.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GradientTileButton11.ForeColor = System.Drawing.Color.White;
            this.guna2GradientTileButton11.HoverState.BorderColor = System.Drawing.Color.GhostWhite;
            this.guna2GradientTileButton11.HoverState.FillColor = System.Drawing.SystemColors.MenuHighlight;
            this.guna2GradientTileButton11.HoverState.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton11.HoverState.ForeColor = System.Drawing.Color.White;
            this.guna2GradientTileButton11.HoverState.Parent = this.guna2GradientTileButton11;
            this.guna2GradientTileButton11.Image = global::SayangDiniUas.Properties.Resources.zyro_image__7_;
            this.guna2GradientTileButton11.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientTileButton11.ImageOffset = new System.Drawing.Point(0, 28);
            this.guna2GradientTileButton11.ImageSize = new System.Drawing.Size(57, 53);
            this.guna2GradientTileButton11.Location = new System.Drawing.Point(9, 373);
            this.guna2GradientTileButton11.Name = "guna2GradientTileButton11";
            this.guna2GradientTileButton11.ShadowDecoration.Parent = this.guna2GradientTileButton11;
            this.guna2GradientTileButton11.Size = new System.Drawing.Size(191, 48);
            this.guna2GradientTileButton11.TabIndex = 102;
            this.guna2GradientTileButton11.Text = "Pengembalian";
            this.guna2GradientTileButton11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientTileButton11.TextOffset = new System.Drawing.Point(10, -28);
            this.guna2GradientTileButton11.Click += new System.EventHandler(this.guna2GradientTileButton11_Click);
            // 
            // guna2GradientTileButton12
            // 
            this.guna2GradientTileButton12.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton12.BorderRadius = 7;
            this.guna2GradientTileButton12.BorderThickness = 2;
            this.guna2GradientTileButton12.CheckedState.Parent = this.guna2GradientTileButton12;
            this.guna2GradientTileButton12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientTileButton12.CustomImages.Parent = this.guna2GradientTileButton12;
            this.guna2GradientTileButton12.FillColor = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton12.FillColor2 = System.Drawing.Color.DarkSlateBlue;
            this.guna2GradientTileButton12.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GradientTileButton12.ForeColor = System.Drawing.Color.White;
            this.guna2GradientTileButton12.HoverState.BorderColor = System.Drawing.Color.GhostWhite;
            this.guna2GradientTileButton12.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.guna2GradientTileButton12.HoverState.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton12.HoverState.ForeColor = System.Drawing.Color.White;
            this.guna2GradientTileButton12.HoverState.Parent = this.guna2GradientTileButton12;
            this.guna2GradientTileButton12.Image = global::SayangDiniUas.Properties.Resources.zyro_image__8_;
            this.guna2GradientTileButton12.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientTileButton12.ImageOffset = new System.Drawing.Point(0, 28);
            this.guna2GradientTileButton12.ImageSize = new System.Drawing.Size(45, 55);
            this.guna2GradientTileButton12.Location = new System.Drawing.Point(12, 427);
            this.guna2GradientTileButton12.Name = "guna2GradientTileButton12";
            this.guna2GradientTileButton12.ShadowDecoration.Parent = this.guna2GradientTileButton12;
            this.guna2GradientTileButton12.Size = new System.Drawing.Size(191, 48);
            this.guna2GradientTileButton12.TabIndex = 103;
            this.guna2GradientTileButton12.Text = "Laporan";
            this.guna2GradientTileButton12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientTileButton12.TextOffset = new System.Drawing.Point(-35, -28);
            this.guna2GradientTileButton12.Click += new System.EventHandler(this.guna2GradientTileButton12_Click);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.Image = global::SayangDiniUas.Properties.Resources.zyro_image__9_;
            this.guna2PictureBox1.Location = new System.Drawing.Point(9, 70);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.ShadowDecoration.Parent = this.guna2PictureBox1;
            this.guna2PictureBox1.Size = new System.Drawing.Size(76, 64);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox1.TabIndex = 104;
            this.guna2PictureBox1.TabStop = false;
            // 
            // guna2GradientTileButton13
            // 
            this.guna2GradientTileButton13.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton13.BorderRadius = 7;
            this.guna2GradientTileButton13.BorderThickness = 2;
            this.guna2GradientTileButton13.CheckedState.Parent = this.guna2GradientTileButton13;
            this.guna2GradientTileButton13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientTileButton13.CustomImages.Parent = this.guna2GradientTileButton13;
            this.guna2GradientTileButton13.FillColor = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton13.FillColor2 = System.Drawing.Color.DarkSlateBlue;
            this.guna2GradientTileButton13.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GradientTileButton13.ForeColor = System.Drawing.Color.White;
            this.guna2GradientTileButton13.HoverState.BorderColor = System.Drawing.Color.GhostWhite;
            this.guna2GradientTileButton13.HoverState.FillColor = System.Drawing.Color.Maroon;
            this.guna2GradientTileButton13.HoverState.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton13.HoverState.ForeColor = System.Drawing.Color.White;
            this.guna2GradientTileButton13.HoverState.Parent = this.guna2GradientTileButton13;
            this.guna2GradientTileButton13.Image = global::SayangDiniUas.Properties.Resources.zyro_image__12_;
            this.guna2GradientTileButton13.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientTileButton13.ImageOffset = new System.Drawing.Point(0, 21);
            this.guna2GradientTileButton13.ImageSize = new System.Drawing.Size(40, 40);
            this.guna2GradientTileButton13.Location = new System.Drawing.Point(9, 481);
            this.guna2GradientTileButton13.Name = "guna2GradientTileButton13";
            this.guna2GradientTileButton13.ShadowDecoration.Parent = this.guna2GradientTileButton13;
            this.guna2GradientTileButton13.Size = new System.Drawing.Size(191, 48);
            this.guna2GradientTileButton13.TabIndex = 105;
            this.guna2GradientTileButton13.Text = "Logout";
            this.guna2GradientTileButton13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientTileButton13.TextOffset = new System.Drawing.Point(-40, -25);
            this.guna2GradientTileButton13.Click += new System.EventHandler(this.guna2GradientTileButton13_Click);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Purple;
            this.panel10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel10.Controls.Add(this.label4);
            this.panel10.Controls.Add(this.pictureBox7);
            this.panel10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel10.Location = new System.Drawing.Point(418, 260);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(196, 77);
            this.panel10.TabIndex = 106;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(80, 5);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 20);
            this.label4.TabIndex = 73;
            this.label4.Text = "Laporan";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::SayangDiniUas.Properties.Resources.zyro_image__8_;
            this.pictureBox7.Location = new System.Drawing.Point(1, 1);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(72, 70);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 83;
            this.pictureBox7.TabStop = false;
            // 
            // dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::SayangDiniUas.Properties.Resources.per;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1028, 608);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.guna2GradientTileButton13);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.guna2GradientTileButton12);
            this.Controls.Add(this.guna2GradientTileButton11);
            this.Controls.Add(this.guna2GradientTileButton10);
            this.Controls.Add(this.guna2GradientTileButton9);
            this.Controls.Add(this.guna2GradientTileButton8);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.guna2GradientTileButton1);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel13);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "dashboard";
            this.Load += new System.EventHandler(this.dashboard_Load);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label bukulbl;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label anggota;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label petugas;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label pinjam;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label kembali;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label12;
        private Guna.UI2.WinForms.Guna2GradientTileButton guna2GradientTileButton1;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel9;
        private Guna.UI2.WinForms.Guna2GradientTileButton guna2GradientTileButton8;
        private Guna.UI2.WinForms.Guna2GradientTileButton guna2GradientTileButton9;
        private Guna.UI2.WinForms.Guna2GradientTileButton guna2GradientTileButton10;
        private Guna.UI2.WinForms.Guna2GradientTileButton guna2GradientTileButton11;
        private Guna.UI2.WinForms.Guna2GradientTileButton guna2GradientTileButton12;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2GradientTileButton guna2GradientTileButton13;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox7;
    }
}