﻿namespace SayangDiniUas
{
    partial class pinjam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(pinjam));
            this.txtbuku = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2TextBox2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtnamaanggota = new Guna.UI2.WinForms.Guna2TextBox();
            this.cbkdanggota = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.guna2TextBox5 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2DataGridView1 = new Guna.UI2.WinForms.Guna2DataGridView();
            this.guna2TextBox9 = new Guna.UI2.WinForms.Guna2TextBox();
            this.cbkdbuku = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.guna2GradientTileButton6 = new Guna.UI2.WinForms.Guna2GradientTileButton();
            this.Cetak_Kartu_Pinjam = new System.Windows.Forms.ListBox();
            this.txtkdpinjam = new Guna.UI2.WinForms.Guna2TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.guna2TextBox7 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2TileButton5 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2TileButton4 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2TileButton3 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2TileButton2 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2TileButton1 = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2TileButton6 = new Guna.UI2.WinForms.Guna2TileButton();
            this.cbpetugas = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tglkembali = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.tglpinjam = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.bunifuTextbox1 = new ns1.BunifuTextbox();
            this.label17 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtbuku
            // 
            this.txtbuku.BackColor = System.Drawing.Color.Transparent;
            this.txtbuku.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtbuku.BorderRadius = 7;
            this.txtbuku.BorderThickness = 2;
            this.txtbuku.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbuku.DefaultText = "";
            this.txtbuku.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtbuku.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtbuku.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtbuku.DisabledState.Parent = this.txtbuku;
            this.txtbuku.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtbuku.FocusedState.BorderColor = System.Drawing.Color.DarkSlateBlue;
            this.txtbuku.FocusedState.Parent = this.txtbuku;
            this.txtbuku.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbuku.ForeColor = System.Drawing.Color.Black;
            this.txtbuku.HoverState.BorderColor = System.Drawing.Color.DarkSlateBlue;
            this.txtbuku.HoverState.Parent = this.txtbuku;
            this.txtbuku.Location = new System.Drawing.Point(977, 99);
            this.txtbuku.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtbuku.Name = "txtbuku";
            this.txtbuku.PasswordChar = '\0';
            this.txtbuku.PlaceholderText = "";
            this.txtbuku.SelectedText = "";
            this.txtbuku.ShadowDecoration.Parent = this.txtbuku;
            this.txtbuku.Size = new System.Drawing.Size(149, 36);
            this.txtbuku.TabIndex = 72;
            // 
            // guna2TextBox2
            // 
            this.guna2TextBox2.BackColor = System.Drawing.Color.Transparent;
            this.guna2TextBox2.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.guna2TextBox2.BorderRadius = 7;
            this.guna2TextBox2.BorderThickness = 2;
            this.guna2TextBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox2.DefaultText = "";
            this.guna2TextBox2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox2.DisabledState.Parent = this.guna2TextBox2;
            this.guna2TextBox2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox2.FocusedState.BorderColor = System.Drawing.Color.DarkSlateBlue;
            this.guna2TextBox2.FocusedState.Parent = this.guna2TextBox2;
            this.guna2TextBox2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox2.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox2.HoverState.BorderColor = System.Drawing.Color.DarkSlateBlue;
            this.guna2TextBox2.HoverState.Parent = this.guna2TextBox2;
            this.guna2TextBox2.Location = new System.Drawing.Point(504, 99);
            this.guna2TextBox2.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.guna2TextBox2.Name = "guna2TextBox2";
            this.guna2TextBox2.PasswordChar = '\0';
            this.guna2TextBox2.PlaceholderText = "";
            this.guna2TextBox2.SelectedText = "";
            this.guna2TextBox2.ShadowDecoration.Parent = this.guna2TextBox2;
            this.guna2TextBox2.Size = new System.Drawing.Size(149, 36);
            this.guna2TextBox2.TabIndex = 71;
            // 
            // txtnamaanggota
            // 
            this.txtnamaanggota.BackColor = System.Drawing.Color.Transparent;
            this.txtnamaanggota.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtnamaanggota.BorderRadius = 7;
            this.txtnamaanggota.BorderThickness = 2;
            this.txtnamaanggota.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtnamaanggota.DefaultText = "";
            this.txtnamaanggota.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtnamaanggota.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtnamaanggota.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtnamaanggota.DisabledState.Parent = this.txtnamaanggota;
            this.txtnamaanggota.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtnamaanggota.FocusedState.BorderColor = System.Drawing.Color.DarkSlateBlue;
            this.txtnamaanggota.FocusedState.Parent = this.txtnamaanggota;
            this.txtnamaanggota.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnamaanggota.ForeColor = System.Drawing.Color.Black;
            this.txtnamaanggota.HoverState.BorderColor = System.Drawing.Color.DarkSlateBlue;
            this.txtnamaanggota.HoverState.Parent = this.txtnamaanggota;
            this.txtnamaanggota.Location = new System.Drawing.Point(345, 99);
            this.txtnamaanggota.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtnamaanggota.Name = "txtnamaanggota";
            this.txtnamaanggota.PasswordChar = '\0';
            this.txtnamaanggota.PlaceholderText = "";
            this.txtnamaanggota.SelectedText = "";
            this.txtnamaanggota.ShadowDecoration.Parent = this.txtnamaanggota;
            this.txtnamaanggota.Size = new System.Drawing.Size(149, 36);
            this.txtnamaanggota.TabIndex = 70;
            // 
            // cbkdanggota
            // 
            this.cbkdanggota.BackColor = System.Drawing.Color.Transparent;
            this.cbkdanggota.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.cbkdanggota.BorderRadius = 7;
            this.cbkdanggota.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cbkdanggota.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbkdanggota.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbkdanggota.FocusedColor = System.Drawing.Color.Empty;
            this.cbkdanggota.FocusedState.Parent = this.cbkdanggota;
            this.cbkdanggota.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbkdanggota.ForeColor = System.Drawing.Color.Black;
            this.cbkdanggota.FormattingEnabled = true;
            this.cbkdanggota.HoverState.Parent = this.cbkdanggota;
            this.cbkdanggota.ItemHeight = 30;
            this.cbkdanggota.Items.AddRange(new object[] {
            "Action",
            "Kartun",
            "Novel"});
            this.cbkdanggota.ItemsAppearance.Parent = this.cbkdanggota;
            this.cbkdanggota.Location = new System.Drawing.Point(188, 99);
            this.cbkdanggota.Name = "cbkdanggota";
            this.cbkdanggota.ShadowDecoration.Parent = this.cbkdanggota;
            this.cbkdanggota.Size = new System.Drawing.Size(149, 36);
            this.cbkdanggota.TabIndex = 69;
            this.cbkdanggota.SelectionChangeCommitted += new System.EventHandler(this.guna2ComboBox1_SelectionChangeCommitted);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label5.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(989, 68);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(125, 26);
            this.label5.TabIndex = 68;
            this.label5.Text = "Judul Buku";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(835, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 26);
            this.label4.TabIndex = 67;
            this.label4.Text = "Kode Buku";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(538, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 26);
            this.label3.TabIndex = 66;
            this.label3.Text = "Alamat";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(345, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 26);
            this.label2.TabIndex = 65;
            this.label2.Text = "Nama Anggota";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(192, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 26);
            this.label1.TabIndex = 64;
            this.label1.Text = "Kode Anggota";
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(0, 54);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 440);
            this.panel2.TabIndex = 22;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Font = new System.Drawing.Font("Kristen ITC", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1139, 48);
            this.panel1.TabIndex = 74;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Gloucester MT Extra Condensed", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(4, 5);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(24, 32);
            this.label10.TabIndex = 98;
            this.label10.Text = "?";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox3.Image = global::SayangDiniUas.Properties.Resources.cancel;
            this.pictureBox3.Location = new System.Drawing.Point(1105, 1);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(34, 33);
            this.pictureBox3.TabIndex = 38;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(471, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(139, 29);
            this.label6.TabIndex = 0;
            this.label6.Text = "Form Pinjam";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel6.Location = new System.Drawing.Point(1134, 47);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(5, 478);
            this.panel6.TabIndex = 80;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Font = new System.Drawing.Font("Kristen ITC", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel5.Location = new System.Drawing.Point(0, 526);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1098, 10);
            this.panel5.TabIndex = 82;
            // 
            // panel7
            // 
            this.panel7.Location = new System.Drawing.Point(0, 54);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(10, 440);
            this.panel7.TabIndex = 22;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel4.Location = new System.Drawing.Point(0, 47);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(5, 479);
            this.panel4.TabIndex = 81;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel3.Location = new System.Drawing.Point(-252, 55);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(10, 396);
            this.panel3.TabIndex = 79;
            // 
            // guna2TextBox5
            // 
            this.guna2TextBox5.BackColor = System.Drawing.Color.Transparent;
            this.guna2TextBox5.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.guna2TextBox5.BorderRadius = 7;
            this.guna2TextBox5.BorderThickness = 2;
            this.guna2TextBox5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox5.DefaultText = "";
            this.guna2TextBox5.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox5.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox5.DisabledState.Parent = this.guna2TextBox5;
            this.guna2TextBox5.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox5.FocusedState.BorderColor = System.Drawing.Color.DarkSlateBlue;
            this.guna2TextBox5.FocusedState.Parent = this.guna2TextBox5;
            this.guna2TextBox5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox5.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox5.HoverState.BorderColor = System.Drawing.Color.DarkSlateBlue;
            this.guna2TextBox5.HoverState.Parent = this.guna2TextBox5;
            this.guna2TextBox5.Location = new System.Drawing.Point(121, 187);
            this.guna2TextBox5.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.guna2TextBox5.Name = "guna2TextBox5";
            this.guna2TextBox5.PasswordChar = '\0';
            this.guna2TextBox5.PlaceholderText = "";
            this.guna2TextBox5.SelectedText = "";
            this.guna2TextBox5.ShadowDecoration.Parent = this.guna2TextBox5;
            this.guna2TextBox5.Size = new System.Drawing.Size(147, 36);
            this.guna2TextBox5.TabIndex = 88;
            // 
            // guna2DataGridView1
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.guna2DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.guna2DataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.guna2DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.DarkSlateBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.guna2DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.guna2DataGridView1.ColumnHeadersHeight = 30;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.guna2DataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.guna2DataGridView1.EnableHeadersVisualStyles = false;
            this.guna2DataGridView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.Location = new System.Drawing.Point(260, 326);
            this.guna2DataGridView1.Name = "guna2DataGridView1";
            this.guna2DataGridView1.RowHeadersVisible = false;
            this.guna2DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.guna2DataGridView1.Size = new System.Drawing.Size(866, 160);
            this.guna2DataGridView1.TabIndex = 84;
            this.guna2DataGridView1.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Default;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2DataGridView1.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.Height = 30;
            this.guna2DataGridView1.ThemeStyle.ReadOnly = false;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.guna2DataGridView1.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView1.ThemeStyle.RowsStyle.Height = 22;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.guna2DataGridView1_CellContentClick);
            // 
            // guna2TextBox9
            // 
            this.guna2TextBox9.BackColor = System.Drawing.Color.Transparent;
            this.guna2TextBox9.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.guna2TextBox9.BorderRadius = 7;
            this.guna2TextBox9.BorderThickness = 2;
            this.guna2TextBox9.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox9.DefaultText = "";
            this.guna2TextBox9.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox9.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox9.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox9.DisabledState.Parent = this.guna2TextBox9;
            this.guna2TextBox9.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox9.FocusedState.BorderColor = System.Drawing.Color.DarkSlateBlue;
            this.guna2TextBox9.FocusedState.Parent = this.guna2TextBox9;
            this.guna2TextBox9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox9.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox9.HoverState.BorderColor = System.Drawing.Color.DarkSlateBlue;
            this.guna2TextBox9.HoverState.Parent = this.guna2TextBox9;
            this.guna2TextBox9.Location = new System.Drawing.Point(293, 187);
            this.guna2TextBox9.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.guna2TextBox9.Name = "guna2TextBox9";
            this.guna2TextBox9.PasswordChar = '\0';
            this.guna2TextBox9.PlaceholderText = "";
            this.guna2TextBox9.SelectedText = "";
            this.guna2TextBox9.ShadowDecoration.Parent = this.guna2TextBox9;
            this.guna2TextBox9.Size = new System.Drawing.Size(147, 36);
            this.guna2TextBox9.TabIndex = 95;
            // 
            // cbkdbuku
            // 
            this.cbkdbuku.BackColor = System.Drawing.Color.Transparent;
            this.cbkdbuku.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.cbkdbuku.BorderRadius = 7;
            this.cbkdbuku.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cbkdbuku.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbkdbuku.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbkdbuku.FocusedColor = System.Drawing.Color.Empty;
            this.cbkdbuku.FocusedState.Parent = this.cbkdbuku;
            this.cbkdbuku.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbkdbuku.ForeColor = System.Drawing.Color.Black;
            this.cbkdbuku.FormattingEnabled = true;
            this.cbkdbuku.HoverState.Parent = this.cbkdbuku;
            this.cbkdbuku.ItemHeight = 30;
            this.cbkdbuku.Items.AddRange(new object[] {
            "Action",
            "Kartun",
            "Novel"});
            this.cbkdbuku.ItemsAppearance.Parent = this.cbkdbuku;
            this.cbkdbuku.Location = new System.Drawing.Point(820, 99);
            this.cbkdbuku.Name = "cbkdbuku";
            this.cbkdbuku.ShadowDecoration.Parent = this.cbkdbuku;
            this.cbkdbuku.Size = new System.Drawing.Size(149, 36);
            this.cbkdbuku.TabIndex = 94;
            this.cbkdbuku.SelectionChangeCommitted += new System.EventHandler(this.guna2ComboBox2_SelectionChangeCommitted);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label12.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(630, 152);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(285, 26);
            this.label12.TabIndex = 92;
            this.label12.Text = "Maksimal Tgl Pengembalian";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label13.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(487, 152);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(122, 26);
            this.label13.TabIndex = 91;
            this.label13.Text = "Tgl Pinjam";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label14.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(321, 152);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(91, 26);
            this.label14.TabIndex = 90;
            this.label14.Text = "Tersedia";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label15.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(152, 152);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(84, 26);
            this.label15.TabIndex = 89;
            this.label15.Text = "Jumlah";
            // 
            // guna2GradientTileButton6
            // 
            this.guna2GradientTileButton6.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton6.BorderRadius = 7;
            this.guna2GradientTileButton6.BorderThickness = 2;
            this.guna2GradientTileButton6.CheckedState.Parent = this.guna2GradientTileButton6;
            this.guna2GradientTileButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientTileButton6.CustomImages.Parent = this.guna2GradientTileButton6;
            this.guna2GradientTileButton6.FillColor = System.Drawing.Color.DarkSlateBlue;
            this.guna2GradientTileButton6.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2GradientTileButton6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GradientTileButton6.ForeColor = System.Drawing.Color.Black;
            this.guna2GradientTileButton6.HoverState.Parent = this.guna2GradientTileButton6;
            this.guna2GradientTileButton6.Location = new System.Drawing.Point(36, 488);
            this.guna2GradientTileButton6.Name = "guna2GradientTileButton6";
            this.guna2GradientTileButton6.ShadowDecoration.Parent = this.guna2GradientTileButton6;
            this.guna2GradientTileButton6.Size = new System.Drawing.Size(184, 27);
            this.guna2GradientTileButton6.TabIndex = 99;
            this.guna2GradientTileButton6.Text = "CETAK KARTU ANGGOTA";
            this.guna2GradientTileButton6.Click += new System.EventHandler(this.guna2GradientTileButton6_Click);
            // 
            // Cetak_Kartu_Pinjam
            // 
            this.Cetak_Kartu_Pinjam.FormattingEnabled = true;
            this.Cetak_Kartu_Pinjam.Location = new System.Drawing.Point(10, 326);
            this.Cetak_Kartu_Pinjam.Name = "Cetak_Kartu_Pinjam";
            this.Cetak_Kartu_Pinjam.Size = new System.Drawing.Size(246, 160);
            this.Cetak_Kartu_Pinjam.TabIndex = 98;
            // 
            // txtkdpinjam
            // 
            this.txtkdpinjam.BackColor = System.Drawing.Color.Transparent;
            this.txtkdpinjam.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtkdpinjam.BorderRadius = 7;
            this.txtkdpinjam.BorderThickness = 2;
            this.txtkdpinjam.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtkdpinjam.DefaultText = "";
            this.txtkdpinjam.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtkdpinjam.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtkdpinjam.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtkdpinjam.DisabledState.Parent = this.txtkdpinjam;
            this.txtkdpinjam.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtkdpinjam.Enabled = false;
            this.txtkdpinjam.FocusedState.BorderColor = System.Drawing.Color.DarkSlateBlue;
            this.txtkdpinjam.FocusedState.Parent = this.txtkdpinjam;
            this.txtkdpinjam.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtkdpinjam.ForeColor = System.Drawing.Color.Black;
            this.txtkdpinjam.HoverState.BorderColor = System.Drawing.Color.DarkSlateBlue;
            this.txtkdpinjam.HoverState.Parent = this.txtkdpinjam;
            this.txtkdpinjam.Location = new System.Drawing.Point(49, 99);
            this.txtkdpinjam.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtkdpinjam.Name = "txtkdpinjam";
            this.txtkdpinjam.PasswordChar = '\0';
            this.txtkdpinjam.PlaceholderText = "";
            this.txtkdpinjam.SelectedText = "";
            this.txtkdpinjam.ShadowDecoration.Parent = this.txtkdpinjam;
            this.txtkdpinjam.Size = new System.Drawing.Size(119, 36);
            this.txtkdpinjam.TabIndex = 101;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label11.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(40, 70);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(137, 26);
            this.label11.TabIndex = 100;
            this.label11.Text = "Kode Pinjam";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label16.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(703, 68);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(69, 26);
            this.label16.TabIndex = 102;
            this.label16.Text = "Status";
            // 
            // guna2TextBox7
            // 
            this.guna2TextBox7.BackColor = System.Drawing.Color.Transparent;
            this.guna2TextBox7.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.guna2TextBox7.BorderRadius = 7;
            this.guna2TextBox7.BorderThickness = 2;
            this.guna2TextBox7.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox7.DefaultText = "";
            this.guna2TextBox7.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox7.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox7.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox7.DisabledState.Parent = this.guna2TextBox7;
            this.guna2TextBox7.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox7.Enabled = false;
            this.guna2TextBox7.FocusedState.BorderColor = System.Drawing.Color.DarkSlateBlue;
            this.guna2TextBox7.FocusedState.Parent = this.guna2TextBox7;
            this.guna2TextBox7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox7.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox7.HoverState.BorderColor = System.Drawing.Color.DarkSlateBlue;
            this.guna2TextBox7.HoverState.Parent = this.guna2TextBox7;
            this.guna2TextBox7.Location = new System.Drawing.Point(663, 99);
            this.guna2TextBox7.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.guna2TextBox7.Name = "guna2TextBox7";
            this.guna2TextBox7.PasswordChar = '\0';
            this.guna2TextBox7.PlaceholderText = "";
            this.guna2TextBox7.SelectedText = "";
            this.guna2TextBox7.ShadowDecoration.Parent = this.guna2TextBox7;
            this.guna2TextBox7.Size = new System.Drawing.Size(149, 36);
            this.guna2TextBox7.TabIndex = 103;
            // 
            // guna2TileButton5
            // 
            this.guna2TileButton5.BackColor = System.Drawing.Color.Transparent;
            this.guna2TileButton5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.guna2TileButton5.BorderRadius = 5;
            this.guna2TileButton5.BorderThickness = 1;
            this.guna2TileButton5.CheckedState.Parent = this.guna2TileButton5;
            this.guna2TileButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2TileButton5.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2TileButton5.CustomImages.Parent = this.guna2TileButton5;
            this.guna2TileButton5.FillColor = System.Drawing.Color.Transparent;
            this.guna2TileButton5.Font = new System.Drawing.Font("Lucida Bright", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TileButton5.ForeColor = System.Drawing.Color.Black;
            this.guna2TileButton5.HoverState.BorderColor = System.Drawing.Color.Black;
            this.guna2TileButton5.HoverState.CustomBorderColor = System.Drawing.Color.White;
            this.guna2TileButton5.HoverState.FillColor = System.Drawing.Color.DodgerBlue;
            this.guna2TileButton5.HoverState.Parent = this.guna2TileButton5;
            this.guna2TileButton5.Image = global::SayangDiniUas.Properties.Resources.zyro_image__1_;
            this.guna2TileButton5.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton5.ImageOffset = new System.Drawing.Point(-7, 16);
            this.guna2TileButton5.ImageSize = new System.Drawing.Size(35, 33);
            this.guna2TileButton5.Location = new System.Drawing.Point(359, 240);
            this.guna2TileButton5.Name = "guna2TileButton5";
            this.guna2TileButton5.ShadowDecoration.Parent = this.guna2TileButton5;
            this.guna2TileButton5.Size = new System.Drawing.Size(107, 35);
            this.guna2TileButton5.TabIndex = 108;
            this.guna2TileButton5.Text = "Update";
            this.guna2TileButton5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2TileButton5.TextOffset = new System.Drawing.Point(9, -16);
            this.guna2TileButton5.Click += new System.EventHandler(this.guna2TileButton5_Click);
            // 
            // guna2TileButton4
            // 
            this.guna2TileButton4.BackColor = System.Drawing.Color.Transparent;
            this.guna2TileButton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.guna2TileButton4.BorderRadius = 5;
            this.guna2TileButton4.BorderThickness = 1;
            this.guna2TileButton4.CheckedState.Parent = this.guna2TileButton4;
            this.guna2TileButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2TileButton4.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2TileButton4.CustomImages.Parent = this.guna2TileButton4;
            this.guna2TileButton4.FillColor = System.Drawing.Color.Transparent;
            this.guna2TileButton4.Font = new System.Drawing.Font("Lucida Bright", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TileButton4.ForeColor = System.Drawing.Color.Black;
            this.guna2TileButton4.HoverState.BorderColor = System.Drawing.Color.Black;
            this.guna2TileButton4.HoverState.CustomBorderColor = System.Drawing.Color.White;
            this.guna2TileButton4.HoverState.FillColor = System.Drawing.Color.Chocolate;
            this.guna2TileButton4.HoverState.Parent = this.guna2TileButton4;
            this.guna2TileButton4.Image = global::SayangDiniUas.Properties.Resources.zyro_image;
            this.guna2TileButton4.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton4.ImageOffset = new System.Drawing.Point(-7, 16);
            this.guna2TileButton4.ImageSize = new System.Drawing.Size(32, 31);
            this.guna2TileButton4.Location = new System.Drawing.Point(700, 239);
            this.guna2TileButton4.Name = "guna2TileButton4";
            this.guna2TileButton4.ShadowDecoration.Parent = this.guna2TileButton4;
            this.guna2TileButton4.Size = new System.Drawing.Size(107, 35);
            this.guna2TileButton4.TabIndex = 107;
            this.guna2TileButton4.Text = "Back";
            this.guna2TileButton4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2TileButton4.TextOffset = new System.Drawing.Point(0, -15);
            this.guna2TileButton4.Click += new System.EventHandler(this.guna2TileButton4_Click);
            // 
            // guna2TileButton3
            // 
            this.guna2TileButton3.BackColor = System.Drawing.Color.Transparent;
            this.guna2TileButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.guna2TileButton3.BorderRadius = 5;
            this.guna2TileButton3.BorderThickness = 1;
            this.guna2TileButton3.CheckedState.Parent = this.guna2TileButton3;
            this.guna2TileButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2TileButton3.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2TileButton3.CustomImages.Parent = this.guna2TileButton3;
            this.guna2TileButton3.FillColor = System.Drawing.Color.Transparent;
            this.guna2TileButton3.Font = new System.Drawing.Font("Lucida Bright", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TileButton3.ForeColor = System.Drawing.Color.Black;
            this.guna2TileButton3.HoverState.BorderColor = System.Drawing.Color.Black;
            this.guna2TileButton3.HoverState.CustomBorderColor = System.Drawing.Color.White;
            this.guna2TileButton3.HoverState.FillColor = System.Drawing.Color.Teal;
            this.guna2TileButton3.HoverState.Parent = this.guna2TileButton3;
            this.guna2TileButton3.Image = global::SayangDiniUas.Properties.Resources.refresh;
            this.guna2TileButton3.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton3.ImageOffset = new System.Drawing.Point(-7, 16);
            this.guna2TileButton3.ImageSize = new System.Drawing.Size(30, 30);
            this.guna2TileButton3.Location = new System.Drawing.Point(587, 239);
            this.guna2TileButton3.Name = "guna2TileButton3";
            this.guna2TileButton3.ShadowDecoration.Parent = this.guna2TileButton3;
            this.guna2TileButton3.Size = new System.Drawing.Size(107, 35);
            this.guna2TileButton3.TabIndex = 106;
            this.guna2TileButton3.Text = "Refresh";
            this.guna2TileButton3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2TileButton3.TextOffset = new System.Drawing.Point(12, -16);
            this.guna2TileButton3.Click += new System.EventHandler(this.guna2TileButton3_Click);
            // 
            // guna2TileButton2
            // 
            this.guna2TileButton2.BackColor = System.Drawing.Color.Transparent;
            this.guna2TileButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.guna2TileButton2.BorderRadius = 5;
            this.guna2TileButton2.BorderThickness = 1;
            this.guna2TileButton2.CheckedState.Parent = this.guna2TileButton2;
            this.guna2TileButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2TileButton2.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2TileButton2.CustomImages.Parent = this.guna2TileButton2;
            this.guna2TileButton2.FillColor = System.Drawing.Color.Transparent;
            this.guna2TileButton2.Font = new System.Drawing.Font("Lucida Bright", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TileButton2.ForeColor = System.Drawing.Color.Black;
            this.guna2TileButton2.HoverState.BorderColor = System.Drawing.Color.Black;
            this.guna2TileButton2.HoverState.CustomBorderColor = System.Drawing.Color.White;
            this.guna2TileButton2.HoverState.FillColor = System.Drawing.Color.Red;
            this.guna2TileButton2.HoverState.Parent = this.guna2TileButton2;
            this.guna2TileButton2.Image = global::SayangDiniUas.Properties.Resources.cancel;
            this.guna2TileButton2.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton2.ImageOffset = new System.Drawing.Point(-7, 16);
            this.guna2TileButton2.ImageSize = new System.Drawing.Size(30, 30);
            this.guna2TileButton2.Location = new System.Drawing.Point(474, 240);
            this.guna2TileButton2.Name = "guna2TileButton2";
            this.guna2TileButton2.ShadowDecoration.Parent = this.guna2TileButton2;
            this.guna2TileButton2.Size = new System.Drawing.Size(107, 35);
            this.guna2TileButton2.TabIndex = 105;
            this.guna2TileButton2.Text = "Hapus";
            this.guna2TileButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2TileButton2.TextOffset = new System.Drawing.Point(4, -16);
            this.guna2TileButton2.Click += new System.EventHandler(this.guna2TileButton2_Click);
            // 
            // guna2TileButton1
            // 
            this.guna2TileButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2TileButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.guna2TileButton1.BorderRadius = 5;
            this.guna2TileButton1.BorderThickness = 1;
            this.guna2TileButton1.CheckedState.Parent = this.guna2TileButton1;
            this.guna2TileButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2TileButton1.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2TileButton1.CustomImages.Parent = this.guna2TileButton1;
            this.guna2TileButton1.FillColor = System.Drawing.Color.Transparent;
            this.guna2TileButton1.Font = new System.Drawing.Font("Lucida Bright", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TileButton1.ForeColor = System.Drawing.Color.Black;
            this.guna2TileButton1.HoverState.BorderColor = System.Drawing.Color.Black;
            this.guna2TileButton1.HoverState.CustomBorderColor = System.Drawing.Color.White;
            this.guna2TileButton1.HoverState.FillColor = System.Drawing.Color.Green;
            this.guna2TileButton1.HoverState.Parent = this.guna2TileButton1;
            this.guna2TileButton1.Image = global::SayangDiniUas.Properties.Resources.tambah;
            this.guna2TileButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton1.ImageOffset = new System.Drawing.Point(-7, 16);
            this.guna2TileButton1.ImageSize = new System.Drawing.Size(30, 30);
            this.guna2TileButton1.Location = new System.Drawing.Point(248, 240);
            this.guna2TileButton1.Name = "guna2TileButton1";
            this.guna2TileButton1.ShadowDecoration.Parent = this.guna2TileButton1;
            this.guna2TileButton1.Size = new System.Drawing.Size(107, 35);
            this.guna2TileButton1.TabIndex = 104;
            this.guna2TileButton1.Text = "Simpan";
            this.guna2TileButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2TileButton1.TextOffset = new System.Drawing.Point(10, -16);
            this.guna2TileButton1.Click += new System.EventHandler(this.guna2TileButton1_Click);
            // 
            // guna2TileButton6
            // 
            this.guna2TileButton6.BackColor = System.Drawing.Color.Transparent;
            this.guna2TileButton6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.guna2TileButton6.BorderRadius = 5;
            this.guna2TileButton6.BorderThickness = 1;
            this.guna2TileButton6.CheckedState.Parent = this.guna2TileButton6;
            this.guna2TileButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2TileButton6.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2TileButton6.CustomImages.Parent = this.guna2TileButton6;
            this.guna2TileButton6.FillColor = System.Drawing.Color.Transparent;
            this.guna2TileButton6.Font = new System.Drawing.Font("Century Schoolbook", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TileButton6.ForeColor = System.Drawing.Color.Black;
            this.guna2TileButton6.HoverState.BorderColor = System.Drawing.Color.Black;
            this.guna2TileButton6.HoverState.CustomBorderColor = System.Drawing.Color.White;
            this.guna2TileButton6.HoverState.FillColor = System.Drawing.Color.Green;
            this.guna2TileButton6.HoverState.Parent = this.guna2TileButton6;
            this.guna2TileButton6.Image = global::SayangDiniUas.Properties.Resources._checked;
            this.guna2TileButton6.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton6.ImageOffset = new System.Drawing.Point(-7, 0);
            this.guna2TileButton6.ImageSize = new System.Drawing.Size(32, 31);
            this.guna2TileButton6.Location = new System.Drawing.Point(10, 99);
            this.guna2TileButton6.Name = "guna2TileButton6";
            this.guna2TileButton6.ShadowDecoration.Parent = this.guna2TileButton6;
            this.guna2TileButton6.Size = new System.Drawing.Size(38, 36);
            this.guna2TileButton6.TabIndex = 146;
            this.guna2TileButton6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2TileButton6.TextOffset = new System.Drawing.Point(0, -15);
            this.guna2TileButton6.Click += new System.EventHandler(this.guna2TileButton6_Click);
            // 
            // cbpetugas
            // 
            this.cbpetugas.BackColor = System.Drawing.Color.Transparent;
            this.cbpetugas.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.cbpetugas.BorderRadius = 7;
            this.cbpetugas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cbpetugas.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbpetugas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbpetugas.FocusedColor = System.Drawing.Color.Empty;
            this.cbpetugas.FocusedState.Parent = this.cbpetugas;
            this.cbpetugas.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbpetugas.ForeColor = System.Drawing.Color.Black;
            this.cbpetugas.FormattingEnabled = true;
            this.cbpetugas.HoverState.Parent = this.cbpetugas;
            this.cbpetugas.ItemHeight = 30;
            this.cbpetugas.Items.AddRange(new object[] {
            "Action",
            "Kartun",
            "Novel"});
            this.cbpetugas.ItemsAppearance.Parent = this.cbpetugas;
            this.cbpetugas.Location = new System.Drawing.Point(925, 187);
            this.cbpetugas.Name = "cbpetugas";
            this.cbpetugas.ShadowDecoration.Parent = this.cbpetugas;
            this.cbpetugas.Size = new System.Drawing.Size(149, 36);
            this.cbpetugas.TabIndex = 148;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label7.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(928, 152);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(138, 26);
            this.label7.TabIndex = 147;
            this.label7.Text = "Kode Petugas";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label8.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(456, 492);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(22, 26);
            this.label8.TabIndex = 150;
            this.label8.Text = "?";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label9.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(262, 492);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(188, 26);
            this.label9.TabIndex = 149;
            this.label9.Text = "Jumlah Peminjam";
            // 
            // tglkembali
            // 
            this.tglkembali.BackColor = System.Drawing.Color.Transparent;
            this.tglkembali.BorderRadius = 7;
            this.tglkembali.BorderThickness = 2;
            this.tglkembali.CheckedState.Parent = this.tglkembali;
            this.tglkembali.FillColor = System.Drawing.Color.DarkSlateBlue;
            this.tglkembali.ForeColor = System.Drawing.Color.White;
            this.tglkembali.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.tglkembali.HoverState.Parent = this.tglkembali;
            this.tglkembali.Location = new System.Drawing.Point(672, 187);
            this.tglkembali.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.tglkembali.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.tglkembali.Name = "tglkembali";
            this.tglkembali.ShadowDecoration.Parent = this.tglkembali;
            this.tglkembali.Size = new System.Drawing.Size(200, 36);
            this.tglkembali.TabIndex = 152;
            this.tglkembali.Value = new System.DateTime(2022, 3, 21, 14, 27, 40, 625);
            // 
            // tglpinjam
            // 
            this.tglpinjam.BackColor = System.Drawing.Color.Transparent;
            this.tglpinjam.BorderRadius = 7;
            this.tglpinjam.BorderThickness = 2;
            this.tglpinjam.CheckedState.Parent = this.tglpinjam;
            this.tglpinjam.FillColor = System.Drawing.Color.DarkSlateBlue;
            this.tglpinjam.ForeColor = System.Drawing.Color.White;
            this.tglpinjam.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.tglpinjam.HoverState.Parent = this.tglpinjam;
            this.tglpinjam.Location = new System.Drawing.Point(448, 187);
            this.tglpinjam.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.tglpinjam.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.tglpinjam.Name = "tglpinjam";
            this.tglpinjam.ShadowDecoration.Parent = this.tglpinjam;
            this.tglpinjam.Size = new System.Drawing.Size(200, 36);
            this.tglpinjam.TabIndex = 151;
            this.tglpinjam.Value = new System.DateTime(2022, 3, 21, 14, 27, 40, 625);
            // 
            // bunifuTextbox1
            // 
            this.bunifuTextbox1.BackColor = System.Drawing.Color.White;
            this.bunifuTextbox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox1.BackgroundImage")));
            this.bunifuTextbox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuTextbox1.ForeColor = System.Drawing.Color.Black;
            this.bunifuTextbox1.Icon = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox1.Icon")));
            this.bunifuTextbox1.Location = new System.Drawing.Point(830, 292);
            this.bunifuTextbox1.Name = "bunifuTextbox1";
            this.bunifuTextbox1.Size = new System.Drawing.Size(296, 31);
            this.bunifuTextbox1.TabIndex = 153;
            this.bunifuTextbox1.text = "";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label17.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(605, 297);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(177, 26);
            this.label17.TabIndex = 154;
            this.label17.Text = "List Peminjaman";
            // 
            // pinjam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SayangDiniUas.Properties.Resources.per;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1140, 535);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.bunifuTextbox1);
            this.Controls.Add(this.tglkembali);
            this.Controls.Add(this.tglpinjam);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.cbpetugas);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.guna2TileButton6);
            this.Controls.Add(this.guna2TileButton5);
            this.Controls.Add(this.guna2TileButton4);
            this.Controls.Add(this.guna2TileButton3);
            this.Controls.Add(this.guna2TileButton2);
            this.Controls.Add(this.guna2TileButton1);
            this.Controls.Add(this.guna2TextBox7);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtkdpinjam);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.guna2GradientTileButton6);
            this.Controls.Add(this.Cetak_Kartu_Pinjam);
            this.Controls.Add(this.guna2TextBox9);
            this.Controls.Add(this.cbkdbuku);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtbuku);
            this.Controls.Add(this.guna2TextBox2);
            this.Controls.Add(this.txtnamaanggota);
            this.Controls.Add(this.cbkdanggota);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.guna2TextBox5);
            this.Controls.Add(this.guna2DataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "pinjam";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "pinjam";
            this.Load += new System.EventHandler(this.pinjam_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox3;
        private Guna.UI2.WinForms.Guna2TextBox txtbuku;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox2;
        private Guna.UI2.WinForms.Guna2TextBox txtnamaanggota;
        private Guna.UI2.WinForms.Guna2ComboBox cbkdanggota;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox5;
        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView1;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox9;
        private Guna.UI2.WinForms.Guna2ComboBox cbkdbuku;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label10;
        private Guna.UI2.WinForms.Guna2GradientTileButton guna2GradientTileButton6;
        private System.Windows.Forms.ListBox Cetak_Kartu_Pinjam;
        private Guna.UI2.WinForms.Guna2TextBox txtkdpinjam;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label16;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox7;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton5;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton4;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton3;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton2;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton1;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton6;
        private Guna.UI2.WinForms.Guna2ComboBox cbpetugas;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2DateTimePicker tglkembali;
        private Guna.UI2.WinForms.Guna2DateTimePicker tglpinjam;
        private ns1.BunifuTextbox bunifuTextbox1;
        private System.Windows.Forms.Label label17;
    }
}