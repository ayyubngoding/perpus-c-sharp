﻿namespace SayangDiniUas
{
    partial class pengembalian
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(pengembalian));
            this.batas = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tglpinjam = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.panel7 = new System.Windows.Forms.Panel();
            this.judulbukutb = new Guna.UI2.WinForms.Guna2TextBox();
            this.namaanggotatb = new Guna.UI2.WinForms.Guna2TextBox();
            this.kpinjamtb = new Guna.UI2.WinForms.Guna2TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.guna2GradientTileButton1 = new Guna.UI2.WinForms.Guna2GradientTileButton();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tglkembali = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.guna2DataGridView1 = new Guna.UI2.WinForms.Guna2DataGridView();
            this.guna2DataGridView2 = new Guna.UI2.WinForms.Guna2DataGridView();
            this.label11 = new System.Windows.Forms.Label();
            this.bunifuTextbox2 = new ns1.BunifuTextbox();
            this.bunifuTextbox1 = new ns1.BunifuTextbox();
            this.guna2TileButton4 = new Guna.UI2.WinForms.Guna2TileButton();
            this.denda = new Guna.UI2.WinForms.Guna2TextBox();
            this.terlambat = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2TileButton1 = new Guna.UI2.WinForms.Guna2TileButton();
            this.label7 = new System.Windows.Forms.Label();
            this.guna2TileButton6 = new Guna.UI2.WinForms.Guna2TileButton();
            this.kembalitb = new Guna.UI2.WinForms.Guna2TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.cbpetugas = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // batas
            // 
            this.batas.BackColor = System.Drawing.Color.Transparent;
            this.batas.BorderRadius = 7;
            this.batas.BorderThickness = 2;
            this.batas.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.batas.CheckedState.Parent = this.batas;
            this.batas.Enabled = false;
            this.batas.FillColor = System.Drawing.Color.DarkSlateBlue;
            this.batas.ForeColor = System.Drawing.Color.White;
            this.batas.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.batas.HoverState.Parent = this.batas;
            this.batas.Location = new System.Drawing.Point(198, 233);
            this.batas.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.batas.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.batas.Name = "batas";
            this.batas.ShadowDecoration.Parent = this.batas;
            this.batas.Size = new System.Drawing.Size(164, 36);
            this.batas.TabIndex = 130;
            this.batas.Value = new System.DateTime(2022, 3, 21, 14, 27, 40, 625);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label12.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(247, 205);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(66, 25);
            this.label12.TabIndex = 126;
            this.label12.Text = "Batas";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label13.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(40, 276);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(131, 25);
            this.label13.TabIndex = 125;
            this.label13.Text = "Tgl Kembali";
            // 
            // tglpinjam
            // 
            this.tglpinjam.BackColor = System.Drawing.Color.Transparent;
            this.tglpinjam.BorderRadius = 7;
            this.tglpinjam.BorderThickness = 2;
            this.tglpinjam.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.tglpinjam.CheckedState.Parent = this.tglpinjam;
            this.tglpinjam.Enabled = false;
            this.tglpinjam.FillColor = System.Drawing.Color.DarkSlateBlue;
            this.tglpinjam.ForeColor = System.Drawing.Color.White;
            this.tglpinjam.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.tglpinjam.HoverState.Parent = this.tglpinjam;
            this.tglpinjam.Location = new System.Drawing.Point(12, 233);
            this.tglpinjam.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.tglpinjam.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.tglpinjam.Name = "tglpinjam";
            this.tglpinjam.ShadowDecoration.Parent = this.tglpinjam;
            this.tglpinjam.Size = new System.Drawing.Size(176, 36);
            this.tglpinjam.TabIndex = 129;
            this.tglpinjam.Value = new System.DateTime(2022, 3, 21, 14, 27, 40, 625);
            // 
            // panel7
            // 
            this.panel7.Location = new System.Drawing.Point(-17, 50);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(10, 440);
            this.panel7.TabIndex = 22;
            // 
            // judulbukutb
            // 
            this.judulbukutb.BackColor = System.Drawing.Color.Transparent;
            this.judulbukutb.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.judulbukutb.BorderRadius = 7;
            this.judulbukutb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.judulbukutb.DefaultText = "";
            this.judulbukutb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.judulbukutb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.judulbukutb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.judulbukutb.DisabledState.Parent = this.judulbukutb;
            this.judulbukutb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.judulbukutb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.judulbukutb.FocusedState.Parent = this.judulbukutb;
            this.judulbukutb.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.judulbukutb.ForeColor = System.Drawing.Color.Black;
            this.judulbukutb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.judulbukutb.HoverState.Parent = this.judulbukutb;
            this.judulbukutb.Location = new System.Drawing.Point(198, 161);
            this.judulbukutb.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.judulbukutb.Name = "judulbukutb";
            this.judulbukutb.PasswordChar = '\0';
            this.judulbukutb.PlaceholderText = "";
            this.judulbukutb.SelectedText = "";
            this.judulbukutb.ShadowDecoration.Parent = this.judulbukutb;
            this.judulbukutb.Size = new System.Drawing.Size(163, 36);
            this.judulbukutb.TabIndex = 106;
            // 
            // namaanggotatb
            // 
            this.namaanggotatb.BackColor = System.Drawing.Color.Transparent;
            this.namaanggotatb.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.namaanggotatb.BorderRadius = 7;
            this.namaanggotatb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.namaanggotatb.DefaultText = "";
            this.namaanggotatb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.namaanggotatb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.namaanggotatb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.namaanggotatb.DisabledState.Parent = this.namaanggotatb;
            this.namaanggotatb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.namaanggotatb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.namaanggotatb.FocusedState.Parent = this.namaanggotatb;
            this.namaanggotatb.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.namaanggotatb.ForeColor = System.Drawing.Color.Black;
            this.namaanggotatb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.namaanggotatb.HoverState.Parent = this.namaanggotatb;
            this.namaanggotatb.Location = new System.Drawing.Point(12, 161);
            this.namaanggotatb.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.namaanggotatb.Name = "namaanggotatb";
            this.namaanggotatb.PasswordChar = '\0';
            this.namaanggotatb.PlaceholderText = "";
            this.namaanggotatb.SelectedText = "";
            this.namaanggotatb.ShadowDecoration.Parent = this.namaanggotatb;
            this.namaanggotatb.Size = new System.Drawing.Size(176, 36);
            this.namaanggotatb.TabIndex = 105;
            // 
            // kpinjamtb
            // 
            this.kpinjamtb.BackColor = System.Drawing.Color.Transparent;
            this.kpinjamtb.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.kpinjamtb.BorderRadius = 7;
            this.kpinjamtb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.kpinjamtb.DefaultText = "";
            this.kpinjamtb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.kpinjamtb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.kpinjamtb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.kpinjamtb.DisabledState.Parent = this.kpinjamtb;
            this.kpinjamtb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.kpinjamtb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.kpinjamtb.FocusedState.Parent = this.kpinjamtb;
            this.kpinjamtb.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kpinjamtb.ForeColor = System.Drawing.Color.Black;
            this.kpinjamtb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.kpinjamtb.HoverState.Parent = this.kpinjamtb;
            this.kpinjamtb.Location = new System.Drawing.Point(198, 89);
            this.kpinjamtb.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.kpinjamtb.Name = "kpinjamtb";
            this.kpinjamtb.PasswordChar = '\0';
            this.kpinjamtb.PlaceholderText = "";
            this.kpinjamtb.SelectedText = "";
            this.kpinjamtb.ShadowDecoration.Parent = this.kpinjamtb;
            this.kpinjamtb.Size = new System.Drawing.Size(163, 37);
            this.kpinjamtb.TabIndex = 104;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label5.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(216, 133);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(126, 25);
            this.label5.TabIndex = 102;
            this.label5.Text = "Judul Buku";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label4.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(44, 346);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 23);
            this.label4.TabIndex = 101;
            this.label4.Text = "Terlambat";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label3.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(244, 348);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 23);
            this.label3.TabIndex = 100;
            this.label3.Text = "Denda";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(210, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 25);
            this.label2.TabIndex = 99;
            this.label2.Text = "Kode Pinjam";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(13, 133);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 25);
            this.label1.TabIndex = 98;
            this.label1.Text = "Nama Anggota";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Font = new System.Drawing.Font("Kristen ITC", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1307, 48);
            this.panel1.TabIndex = 108;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Gloucester MT Extra Condensed", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(10, 6);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(24, 32);
            this.label9.TabIndex = 99;
            this.label9.Text = "?";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox3.Image = global::SayangDiniUas.Properties.Resources.cancel;
            this.pictureBox3.Location = new System.Drawing.Point(1279, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(34, 33);
            this.pictureBox3.TabIndex = 38;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(-17, 50);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 440);
            this.panel2.TabIndex = 22;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(510, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(153, 29);
            this.label6.TabIndex = 0;
            this.label6.Text = "Form Kembali";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel6.Location = new System.Drawing.Point(1305, 48);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(3, 533);
            this.panel6.TabIndex = 114;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Font = new System.Drawing.Font("Kristen ITC", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel5.Location = new System.Drawing.Point(-1, 580);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1309, 10);
            this.panel5.TabIndex = 116;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel4.Location = new System.Drawing.Point(0, 47);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(3, 532);
            this.panel4.TabIndex = 115;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel3.Location = new System.Drawing.Point(-262, 54);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(10, 396);
            this.panel3.TabIndex = 113;
            // 
            // guna2GradientTileButton1
            // 
            this.guna2GradientTileButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton1.BorderRadius = 7;
            this.guna2GradientTileButton1.BorderThickness = 2;
            this.guna2GradientTileButton1.CheckedState.Parent = this.guna2GradientTileButton1;
            this.guna2GradientTileButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientTileButton1.CustomImages.Parent = this.guna2GradientTileButton1;
            this.guna2GradientTileButton1.FillColor = System.Drawing.Color.DarkSlateBlue;
            this.guna2GradientTileButton1.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2GradientTileButton1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GradientTileButton1.ForeColor = System.Drawing.Color.White;
            this.guna2GradientTileButton1.HoverState.BorderColor = System.Drawing.Color.GhostWhite;
            this.guna2GradientTileButton1.HoverState.Parent = this.guna2GradientTileButton1;
            this.guna2GradientTileButton1.Location = new System.Drawing.Point(75, 494);
            this.guna2GradientTileButton1.Name = "guna2GradientTileButton1";
            this.guna2GradientTileButton1.ShadowDecoration.Parent = this.guna2GradientTileButton1;
            this.guna2GradientTileButton1.Size = new System.Drawing.Size(189, 42);
            this.guna2GradientTileButton1.TabIndex = 109;
            this.guna2GradientTileButton1.Text = "Kembalikan Buku";
            this.guna2GradientTileButton1.Click += new System.EventHandler(this.guna2GradientTileButton1_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label8.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(673, 58);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(155, 25);
            this.label8.TabIndex = 117;
            this.label8.Text = "List Peminjam";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label10.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(31, 205);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(118, 25);
            this.label10.TabIndex = 131;
            this.label10.Text = "Tgl Pinjam";
            // 
            // tglkembali
            // 
            this.tglkembali.BackColor = System.Drawing.Color.Transparent;
            this.tglkembali.BorderRadius = 7;
            this.tglkembali.BorderThickness = 2;
            this.tglkembali.CheckedState.Parent = this.tglkembali;
            this.tglkembali.FillColor = System.Drawing.Color.DarkSlateBlue;
            this.tglkembali.ForeColor = System.Drawing.Color.White;
            this.tglkembali.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.tglkembali.HoverState.Parent = this.tglkembali;
            this.tglkembali.Location = new System.Drawing.Point(11, 305);
            this.tglkembali.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.tglkembali.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.tglkembali.Name = "tglkembali";
            this.tglkembali.ShadowDecoration.Parent = this.tglkembali;
            this.tglkembali.Size = new System.Drawing.Size(177, 36);
            this.tglkembali.TabIndex = 132;
            this.tglkembali.Value = new System.DateTime(2022, 3, 21, 14, 27, 40, 625);
            // 
            // guna2DataGridView1
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.guna2DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.guna2DataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.guna2DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.guna2DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.guna2DataGridView1.ColumnHeadersHeight = 30;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.guna2DataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.guna2DataGridView1.EnableHeadersVisualStyles = false;
            this.guna2DataGridView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.Location = new System.Drawing.Point(371, 87);
            this.guna2DataGridView1.Name = "guna2DataGridView1";
            this.guna2DataGridView1.RowHeadersVisible = false;
            this.guna2DataGridView1.RowTemplate.Height = 30;
            this.guna2DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.guna2DataGridView1.Size = new System.Drawing.Size(928, 186);
            this.guna2DataGridView1.TabIndex = 133;
            this.guna2DataGridView1.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Default;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView1.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2DataGridView1.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.Black;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView1.ThemeStyle.HeaderStyle.Height = 30;
            this.guna2DataGridView1.ThemeStyle.ReadOnly = false;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DataGridView1.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView1.ThemeStyle.RowsStyle.Height = 30;
            this.guna2DataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.guna2DataGridView1_CellContentClick);
            // 
            // guna2DataGridView2
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.guna2DataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.guna2DataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2DataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.guna2DataGridView2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.guna2DataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.guna2DataGridView2.ColumnHeadersHeight = 30;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.guna2DataGridView2.DefaultCellStyle = dataGridViewCellStyle6;
            this.guna2DataGridView2.EnableHeadersVisualStyles = false;
            this.guna2DataGridView2.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView2.Location = new System.Drawing.Point(371, 339);
            this.guna2DataGridView2.Name = "guna2DataGridView2";
            this.guna2DataGridView2.RowHeadersVisible = false;
            this.guna2DataGridView2.RowTemplate.Height = 30;
            this.guna2DataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.guna2DataGridView2.Size = new System.Drawing.Size(928, 186);
            this.guna2DataGridView2.TabIndex = 135;
            this.guna2DataGridView2.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Default;
            this.guna2DataGridView2.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView2.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.guna2DataGridView2.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView2.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.guna2DataGridView2.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView2.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2DataGridView2.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView2.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.guna2DataGridView2.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.guna2DataGridView2.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DataGridView2.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.Black;
            this.guna2DataGridView2.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView2.ThemeStyle.HeaderStyle.Height = 30;
            this.guna2DataGridView2.ThemeStyle.ReadOnly = false;
            this.guna2DataGridView2.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView2.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView2.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DataGridView2.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView2.ThemeStyle.RowsStyle.Height = 30;
            this.guna2DataGridView2.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView2.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label11.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(653, 310);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(194, 25);
            this.label11.TabIndex = 134;
            this.label11.Text = "List Pengembalian";
            // 
            // bunifuTextbox2
            // 
            this.bunifuTextbox2.BackColor = System.Drawing.Color.Silver;
            this.bunifuTextbox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox2.BackgroundImage")));
            this.bunifuTextbox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuTextbox2.ForeColor = System.Drawing.Color.Black;
            this.bunifuTextbox2.Icon = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox2.Icon")));
            this.bunifuTextbox2.Location = new System.Drawing.Point(1066, 311);
            this.bunifuTextbox2.Name = "bunifuTextbox2";
            this.bunifuTextbox2.Size = new System.Drawing.Size(232, 27);
            this.bunifuTextbox2.TabIndex = 139;
            this.bunifuTextbox2.text = "";
            this.bunifuTextbox2.OnTextChange += new System.EventHandler(this.bunifuTextbox2_OnTextChange);
            // 
            // bunifuTextbox1
            // 
            this.bunifuTextbox1.BackColor = System.Drawing.Color.Silver;
            this.bunifuTextbox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox1.BackgroundImage")));
            this.bunifuTextbox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuTextbox1.ForeColor = System.Drawing.Color.Black;
            this.bunifuTextbox1.Icon = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox1.Icon")));
            this.bunifuTextbox1.Location = new System.Drawing.Point(1067, 60);
            this.bunifuTextbox1.Name = "bunifuTextbox1";
            this.bunifuTextbox1.Size = new System.Drawing.Size(232, 27);
            this.bunifuTextbox1.TabIndex = 138;
            this.bunifuTextbox1.text = "";
            this.bunifuTextbox1.OnTextChange += new System.EventHandler(this.bunifuTextbox1_OnTextChange);
            // 
            // guna2TileButton4
            // 
            this.guna2TileButton4.BackColor = System.Drawing.Color.Transparent;
            this.guna2TileButton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.guna2TileButton4.BorderRadius = 5;
            this.guna2TileButton4.BorderThickness = 1;
            this.guna2TileButton4.CheckedState.Parent = this.guna2TileButton4;
            this.guna2TileButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2TileButton4.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2TileButton4.CustomImages.Parent = this.guna2TileButton4;
            this.guna2TileButton4.FillColor = System.Drawing.Color.Transparent;
            this.guna2TileButton4.Font = new System.Drawing.Font("Century Schoolbook", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TileButton4.ForeColor = System.Drawing.Color.Black;
            this.guna2TileButton4.HoverState.BorderColor = System.Drawing.Color.Black;
            this.guna2TileButton4.HoverState.CustomBorderColor = System.Drawing.Color.White;
            this.guna2TileButton4.HoverState.FillColor = System.Drawing.Color.Chocolate;
            this.guna2TileButton4.HoverState.Parent = this.guna2TileButton4;
            this.guna2TileButton4.Image = global::SayangDiniUas.Properties.Resources.zyro_image;
            this.guna2TileButton4.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton4.ImageOffset = new System.Drawing.Point(0, 16);
            this.guna2TileButton4.ImageSize = new System.Drawing.Size(32, 31);
            this.guna2TileButton4.Location = new System.Drawing.Point(116, 542);
            this.guna2TileButton4.Name = "guna2TileButton4";
            this.guna2TileButton4.ShadowDecoration.Parent = this.guna2TileButton4;
            this.guna2TileButton4.Size = new System.Drawing.Size(107, 35);
            this.guna2TileButton4.TabIndex = 140;
            this.guna2TileButton4.Text = "Back";
            this.guna2TileButton4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2TileButton4.TextOffset = new System.Drawing.Point(0, -15);
            this.guna2TileButton4.Click += new System.EventHandler(this.guna2TileButton4_Click);
            // 
            // denda
            // 
            this.denda.BackColor = System.Drawing.Color.Transparent;
            this.denda.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.denda.BorderRadius = 7;
            this.denda.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.denda.DefaultText = "";
            this.denda.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.denda.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.denda.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.denda.DisabledState.Parent = this.denda;
            this.denda.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.denda.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.denda.FocusedState.Parent = this.denda;
            this.denda.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.denda.ForeColor = System.Drawing.Color.Black;
            this.denda.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.denda.HoverState.Parent = this.denda;
            this.denda.Location = new System.Drawing.Point(198, 375);
            this.denda.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.denda.Name = "denda";
            this.denda.PasswordChar = '\0';
            this.denda.PlaceholderText = "";
            this.denda.SelectedText = "";
            this.denda.ShadowDecoration.Parent = this.denda;
            this.denda.Size = new System.Drawing.Size(166, 37);
            this.denda.TabIndex = 142;
            // 
            // terlambat
            // 
            this.terlambat.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.terlambat.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.terlambat.BorderRadius = 7;
            this.terlambat.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.terlambat.DefaultText = "";
            this.terlambat.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.terlambat.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.terlambat.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.terlambat.DisabledState.Parent = this.terlambat;
            this.terlambat.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.terlambat.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.terlambat.FocusedState.Parent = this.terlambat;
            this.terlambat.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.terlambat.ForeColor = System.Drawing.Color.Black;
            this.terlambat.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.terlambat.HoverState.Parent = this.terlambat;
            this.terlambat.Location = new System.Drawing.Point(12, 375);
            this.terlambat.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.terlambat.Name = "terlambat";
            this.terlambat.PasswordChar = '\0';
            this.terlambat.PlaceholderText = "";
            this.terlambat.SelectedText = "";
            this.terlambat.ShadowDecoration.Parent = this.terlambat;
            this.terlambat.Size = new System.Drawing.Size(176, 37);
            this.terlambat.TabIndex = 143;
            // 
            // guna2TileButton1
            // 
            this.guna2TileButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2TileButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.guna2TileButton1.BorderRadius = 5;
            this.guna2TileButton1.BorderThickness = 1;
            this.guna2TileButton1.CheckedState.Parent = this.guna2TileButton1;
            this.guna2TileButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2TileButton1.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2TileButton1.CustomImages.Parent = this.guna2TileButton1;
            this.guna2TileButton1.FillColor = System.Drawing.Color.Transparent;
            this.guna2TileButton1.Font = new System.Drawing.Font("Century Schoolbook", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TileButton1.ForeColor = System.Drawing.Color.Black;
            this.guna2TileButton1.HoverState.BorderColor = System.Drawing.Color.Black;
            this.guna2TileButton1.HoverState.CustomBorderColor = System.Drawing.Color.White;
            this.guna2TileButton1.HoverState.FillColor = System.Drawing.Color.Teal;
            this.guna2TileButton1.HoverState.Parent = this.guna2TileButton1;
            this.guna2TileButton1.Image = global::SayangDiniUas.Properties.Resources.checked1;
            this.guna2TileButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton1.ImageOffset = new System.Drawing.Point(-6, 16);
            this.guna2TileButton1.ImageSize = new System.Drawing.Size(32, 31);
            this.guna2TileButton1.Location = new System.Drawing.Point(226, 306);
            this.guna2TileButton1.Name = "guna2TileButton1";
            this.guna2TileButton1.ShadowDecoration.Parent = this.guna2TileButton1;
            this.guna2TileButton1.Size = new System.Drawing.Size(107, 35);
            this.guna2TileButton1.TabIndex = 144;
            this.guna2TileButton1.Text = "Proses";
            this.guna2TileButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2TileButton1.TextOffset = new System.Drawing.Point(0, -17);
            this.guna2TileButton1.Click += new System.EventHandler(this.guna2TileButton1_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Gloucester MT Extra Condensed", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(379, 304);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(24, 32);
            this.label7.TabIndex = 100;
            this.label7.Text = "?";
            // 
            // guna2TileButton6
            // 
            this.guna2TileButton6.BackColor = System.Drawing.Color.Transparent;
            this.guna2TileButton6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.guna2TileButton6.BorderRadius = 5;
            this.guna2TileButton6.BorderThickness = 1;
            this.guna2TileButton6.CheckedState.Parent = this.guna2TileButton6;
            this.guna2TileButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2TileButton6.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2TileButton6.CustomImages.Parent = this.guna2TileButton6;
            this.guna2TileButton6.FillColor = System.Drawing.Color.Transparent;
            this.guna2TileButton6.Font = new System.Drawing.Font("Century Schoolbook", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TileButton6.ForeColor = System.Drawing.Color.Black;
            this.guna2TileButton6.HoverState.BorderColor = System.Drawing.Color.Black;
            this.guna2TileButton6.HoverState.CustomBorderColor = System.Drawing.Color.White;
            this.guna2TileButton6.HoverState.FillColor = System.Drawing.Color.Green;
            this.guna2TileButton6.HoverState.Parent = this.guna2TileButton6;
            this.guna2TileButton6.Image = global::SayangDiniUas.Properties.Resources._checked;
            this.guna2TileButton6.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2TileButton6.ImageOffset = new System.Drawing.Point(-7, 0);
            this.guna2TileButton6.ImageSize = new System.Drawing.Size(32, 31);
            this.guna2TileButton6.Location = new System.Drawing.Point(6, 89);
            this.guna2TileButton6.Name = "guna2TileButton6";
            this.guna2TileButton6.ShadowDecoration.Parent = this.guna2TileButton6;
            this.guna2TileButton6.Size = new System.Drawing.Size(38, 36);
            this.guna2TileButton6.TabIndex = 145;
            this.guna2TileButton6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2TileButton6.TextOffset = new System.Drawing.Point(0, -15);
            this.guna2TileButton6.Click += new System.EventHandler(this.guna2TileButton6_Click);
            // 
            // kembalitb
            // 
            this.kembalitb.BackColor = System.Drawing.Color.Transparent;
            this.kembalitb.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.kembalitb.BorderRadius = 7;
            this.kembalitb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.kembalitb.DefaultText = "";
            this.kembalitb.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.kembalitb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.kembalitb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.kembalitb.DisabledState.Parent = this.kembalitb;
            this.kembalitb.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.kembalitb.Enabled = false;
            this.kembalitb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.kembalitb.FocusedState.Parent = this.kembalitb;
            this.kembalitb.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kembalitb.ForeColor = System.Drawing.Color.Black;
            this.kembalitb.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.kembalitb.HoverState.Parent = this.kembalitb;
            this.kembalitb.Location = new System.Drawing.Point(46, 88);
            this.kembalitb.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.kembalitb.Name = "kembalitb";
            this.kembalitb.PasswordChar = '\0';
            this.kembalitb.PlaceholderText = "";
            this.kembalitb.SelectedText = "";
            this.kembalitb.ShadowDecoration.Parent = this.kembalitb;
            this.kembalitb.Size = new System.Drawing.Size(142, 37);
            this.kembalitb.TabIndex = 147;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label14.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(36, 60);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(152, 25);
            this.label14.TabIndex = 146;
            this.label14.Text = "Kode Kembali";
            // 
            // cbpetugas
            // 
            this.cbpetugas.BackColor = System.Drawing.Color.Transparent;
            this.cbpetugas.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.cbpetugas.BorderRadius = 7;
            this.cbpetugas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cbpetugas.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbpetugas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbpetugas.FocusedColor = System.Drawing.Color.Empty;
            this.cbpetugas.FocusedState.Parent = this.cbpetugas;
            this.cbpetugas.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbpetugas.ForeColor = System.Drawing.Color.Black;
            this.cbpetugas.FormattingEnabled = true;
            this.cbpetugas.HoverState.Parent = this.cbpetugas;
            this.cbpetugas.ItemHeight = 30;
            this.cbpetugas.Items.AddRange(new object[] {
            "Action",
            "Kartun",
            "Novel"});
            this.cbpetugas.ItemsAppearance.Parent = this.cbpetugas;
            this.cbpetugas.Location = new System.Drawing.Point(99, 451);
            this.cbpetugas.Name = "cbpetugas";
            this.cbpetugas.ShadowDecoration.Parent = this.cbpetugas;
            this.cbpetugas.Size = new System.Drawing.Size(149, 36);
            this.cbpetugas.TabIndex = 150;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(103, 422);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(142, 26);
            this.label15.TabIndex = 149;
            this.label15.Text = "Kode Petugas";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Franklin Gothic Demi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(571, 542);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(20, 24);
            this.label16.TabIndex = 152;
            this.label16.Text = "?";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Franklin Gothic Demi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(327, 542);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(238, 24);
            this.label17.TabIndex = 151;
            this.label17.Text = "Jumlah Pengembalian Buku";
            // 
            // pengembalian
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SayangDiniUas.Properties.Resources.per;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1309, 591);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.cbpetugas);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.kembalitb);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.guna2TileButton6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.guna2TileButton1);
            this.Controls.Add(this.terlambat);
            this.Controls.Add(this.denda);
            this.Controls.Add(this.guna2TileButton4);
            this.Controls.Add(this.bunifuTextbox2);
            this.Controls.Add(this.bunifuTextbox1);
            this.Controls.Add(this.guna2DataGridView2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.guna2DataGridView1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.tglkembali);
            this.Controls.Add(this.batas);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.tglpinjam);
            this.Controls.Add(this.judulbukutb);
            this.Controls.Add(this.namaanggotatb);
            this.Controls.Add(this.kpinjamtb);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.guna2GradientTileButton1);
            this.Controls.Add(this.label8);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "pengembalian";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "pengembalian";
            this.Load += new System.EventHandler(this.pengembalian_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2DateTimePicker batas;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureBox3;
        private Guna.UI2.WinForms.Guna2DateTimePicker tglpinjam;
        private System.Windows.Forms.Panel panel7;
        private Guna.UI2.WinForms.Guna2TextBox judulbukutb;
        private Guna.UI2.WinForms.Guna2TextBox namaanggotatb;
        private Guna.UI2.WinForms.Guna2TextBox kpinjamtb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private Guna.UI2.WinForms.Guna2GradientTileButton guna2GradientTileButton1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private Guna.UI2.WinForms.Guna2DateTimePicker tglkembali;
        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView1;
        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView2;
        private System.Windows.Forms.Label label11;
        private ns1.BunifuTextbox bunifuTextbox1;
        private ns1.BunifuTextbox bunifuTextbox2;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton4;
        private Guna.UI2.WinForms.Guna2TextBox denda;
        private Guna.UI2.WinForms.Guna2TextBox terlambat;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton1;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton6;
        private Guna.UI2.WinForms.Guna2TextBox kembalitb;
        private System.Windows.Forms.Label label14;
        private Guna.UI2.WinForms.Guna2ComboBox cbpetugas;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
    }
}